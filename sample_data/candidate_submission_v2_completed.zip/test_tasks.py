import unittest
from app import app

class TaskTestCase(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def test_validation_short_title(self):
        resp = self.client.post('/tasks', json={'title': 'hi'})
        self.assertEqual(resp.status_code, 422)

    def test_valid_task_creation(self):
        resp = self.client.post('/tasks', json={'title': 'Valid Task Title'})
        self.assertEqual(resp.status_code, 201)

if __name__ == '__main__':
    unittest.main()
