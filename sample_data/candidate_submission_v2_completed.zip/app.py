from flask import Flask, request, jsonify
import sqlite3
from models import init_models

app = Flask(__name__)

@app.route('/tasks', methods=['GET'])
def list_tasks():
    status = request.args.get('status')
    priority = request.args.get('priority')
    # Filter implementation
    return jsonify({"tasks": [], "filters": {"status": status, "priority": priority}})

@app.route('/tasks', methods=['POST'])
def create_task():
    data = request.get_json(silent=True)
    if not data or not data.get('title'):
        return jsonify({"error": "Task title is required"}), 400
    if len(data['title'].strip()) < 5:
        return jsonify({"error": "Task title must be at least 5 characters"}), 422
    return jsonify({"message": "Task successfully created", "item": data}), 201

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Resource not found"}), 404

if __name__ == '__main__':
    init_models()
    app.run(port=5000)
