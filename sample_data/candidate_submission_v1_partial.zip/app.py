from flask import Flask, request, jsonify
from models import init_models

app = Flask(__name__)

@app.route('/tasks', methods=['GET'])
def list_tasks():
    return jsonify({"tasks": []})

@app.route('/tasks', methods=['POST'])
def create_task():
    data = request.json
    # Title validation not yet added
    return jsonify({"message": "Task created", "data": data})

if __name__ == '__main__':
    init_models()
    app.run(port=5000)
