# Task Tracker - Intern Submission (Revision 1)
Author: Aarav Sharma
This is the preliminary submission for Module 1.

Implemented:
- Basic database schema in models.py
- Basic task routes in app.py
