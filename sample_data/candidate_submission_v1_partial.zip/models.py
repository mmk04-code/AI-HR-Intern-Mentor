import sqlite3

def init_models():
    conn = sqlite3.connect("tasks.db")
    conn.execute('''CREATE TABLE IF NOT EXISTS TaskItem (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        status TEXT,
        project_id INTEGER
    )''')
    conn.commit()
    conn.close()
